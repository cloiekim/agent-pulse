# Handoff: Agent Pulse — macOS menu bar status app

## Overview
A macOS menu bar app (paired with a Chrome extension) that surfaces the live state of Claude and ChatGPT agent sessions — CLI runs and browser tabs alike. The menu bar item reports the single most urgent state at a glance; clicking it opens a 344px popover listing every session, sorted by urgency, plus usage/weekly-limit meters per provider.

The design work covered three things, all confirmed:
1. The **logo** (waveform mark) and its app-icon / menu-bar-template exports.
2. The **menu bar item**: what it shows in each state, and how much width it is allowed to take.
3. **Astryx design-system overrides** needed to make a full-size design system work inside a 344px popover, plus a status color axis Astryx does not ship.

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes showing intended look and behavior, not production code to copy directly.

The real target here is a **native macOS menu bar app** (`NSStatusItem`) plus a Chrome extension. Recreate these designs in that environment — SwiftUI or AppKit for the menu bar app, and whatever the extension's existing stack is for its surfaces. Do not ship the HTML. Where this README describes CSS-ish values (px, hex, border-radius), translate them to the platform's equivalent; the numbers are the intent, not the API.

## Fidelity
**High-fidelity.** Colors, type, spacing, and states are final. Recreate pixel-accurately, using the codebase's existing component library where one exists.

One caveat: the menu bar mockups are drawn as HTML approximations of the macOS menu bar. Treat the *glyph size, capsule geometry, colors and copy* as final, but expect to hand-tune vertical centering and optical sizing against a real `NSStatusItem`, which the browser cannot simulate.

---

## Screens / Views

### 1. Menu bar item (`NSStatusItem`)

**Purpose:** Tell the user, without them looking directly at it, whether anything needs them.

**Layout:** A custom status-item view (not a plain template image — the count text and the capsule fill both require it). Content is a horizontal row, vertically centered in the 22px usable band of the 24px bar. Height of the capsule is 19px, leaving ~1.5px above and below.

**Four states.** The bar stays monochrome until something actually needs the user:

| State | Treatment | Width (approx) |
|---|---|---|
| Idle | Bare template glyph, 15×15, 55% opacity | 15px |
| Running | Hairline capsule: 1px stroke at 70% of the label color, glyph 14×14 + count | ~46px |
| Needs approval | Filled capsule `#FDCF4F`, glyph + label `#332600` | ~92px |
| Failed | Filled capsule `#D94F4A`, glyph + label `#FFF0EF` | ~88px |

Light-desktop equivalents: running stroke `rgba(47,48,51,0.55)`; approval fill `#E8B41F` with `#2B2000` content; failed fill `#C9403B` with `#FFF0EF` content.

**Capsule geometry (all states with a capsule):**
- `border-radius`: fully round (9999px)
- `padding`: 2px right 8px, left 5px — asymmetric, because the glyph needs less optical inset than text
- `gap` between glyph and label: **2px**
- Glyph inside a capsule: 14×14. Standalone glyph (idle): 15×15.
- Label: 11px, weight 500, `line-height: 1.2`, `white-space: nowrap`

**Copy rules:**
- Count leads, so the item reads quantity-then-state: "1 approve", "3 running", "1 failed".
- Labels are capped at **two words**. "1 needs approval" was rejected — it pushes past 130px and starts crowding the clock.

**Why the glyph sits *inside* the capsule:** a glyph with a gap next to a separate pill reads as two menu bar items. One object is unambiguous, and the glyph gets the capsule's fill contrast for free instead of depending on the system template tint.

**Explicitly deferred:** enclosing the waveform in a circle. It helps slightly in icon-only mode but hurts inside the capsule, and maintaining two silhouettes of one mark is not worth it at this size. Revisit only if icon-only mode tests weak in practice.

**Implementation notes:**
- Filled capsules are **not** template images (`isTemplate = false`), so they do not auto-invert. Two consequences: (a) observe `effectiveAppearance` and swap the light/dark asset pair yourself; (b) while the menu is open the bar highlights with the accent color — swap to the template/monochrome version for the duration so the colored capsule does not muddy against it.
- Debounce state changes ~0.5–1s so a fast-flipping session does not strobe the bar. Downgrades (approval → running) should lag slightly more than upgrades.
- Idle keeps a rendered glyph rather than hiding, so the item never changes width unexpectedly at rest.

### 2. Menu bar icon setting (submenu)

**Purpose:** Let the user cap how much menu bar width the app may take.

**Placement:** First row beneath the account header in the settings popover, above Notifications — it is the only setting that changes what the user sees all day, and the two together govern how loudly the app speaks.

**Row:** 32px tall, 8px radius, 10px horizontal padding. Label left (13px, primary text color), current value right (12px, muted) with a `›` disclosure — so the active mode is readable without opening the submenu.

**Submenu:** two options only. Each shows a live preview of its own glyph on the right edge.

| Option | Preview | Default |
|---|---|---|
| Icon only | Glyph + 6px status-colored dot, offset `top:-1px; right:-3px` | |
| Icon + label | The filled capsule | ✅ |

Selected row: `#2F6FED` background, white text, leading ✓ in a 13px-wide fixed gutter (unselected rows keep the gutter, transparent, so labels stay aligned).

Two options rather than four — the setting is about width, and anything finer is a preference nobody holds.

### 3. Session dropdown (4a) and settings popover (5a)

The confirmed base mocks. See `Menubar MVP - Confirmed.dc.html`, anchors `#4a` and `#5a`. Popover width 344px. Up to 6 rows, sorted Approve → Failed → Running → Waiting → Done, with a "Show N more" overflow row. Each row carries an avatar badge distinguishing CLI (❯) from browser tab (▢) and a source label ("Claude · my-repo"). Footer groups Claude and ChatGPT usage bars separately with brand-colored fills.

---

## Interactions & Behavior
- **Click menu bar item** → toggle the session popover.
- **Click a session row** → focus that CLI session or browser tab.
- **Approve button** → the only accent-blue-weight element in a row, so the eye lands on the action rather than the status label.
- **Menu open** → swap the colored capsule for its monochrome template equivalent (see above).
- **State change** → debounce 0.5–1s.
- Running may animate a subtle pulse; nothing else animates in the bar.

## State Management
Per session: `id`, `provider` (claude | chatgpt), `surface` (cli | tab), `sourceLabel`, `status` (running | needsApproval | waiting | done | failed), `updatedAt`.

Derived, and what the menu bar renders from:
- `aggregateStatus` = highest-priority status present, in the order approval → failed → running → waiting → done → idle.
- `count` = number of sessions in `aggregateStatus`.
- `menuBarMode` = user setting, `iconOnly | iconAndLabel`.
- `appearance` = system light/dark, observed not cached.

Also needed: per-provider usage and weekly-limit values for the footer meters.

## Design Tokens

### Status colors (shared by menu bar and dropdown chips)
| Token | Hex | Notes |
|---|---|---|
| `status.running` | `#3FA35F` | held two steps below amber in saturation so running never out-shouts approval |
| `status.attention` | `#FDCF4F` | the loudest value in the system |
| `status.failed` | `#D94F4A` | |
| `status.waiting` | neutral | no color budget |
| `status.done` | neutral + `#3FA35F` dot | a second green fill would flatten the hierarchy |

Menu-bar-only variants (light desktop): running text `rgba(47,48,51,0.55)`, attention `#E8B41F` on `#2B2000`, failed `#C9403B` on `#FFF0EF`.

### Chip palette (dropdown rows, filled, 20px tall)
| State | Dark bg / fg | Light bg / fg |
|---|---|---|
| Running | `rgba(63,163,95,0.24)` / `#8FD6A6` | `#CFEEDA` / `#1C6537` |
| Needs approval | `rgba(253,207,79,0.22)` / `#FDCF4F` | `#FBE6B2` / `#6B5200` |
| Failed | `rgba(217,79,74,0.24)` / `#FF9A95` | `#FBD9D7` / `#8F2B27` |
| Waiting | `rgba(255,255,255,0.10)` / `#E5E5E5` | `#EEEEEE` / `#404040` |
| Done | `rgba(255,255,255,0.08)` / `#A3A3A3` + green dot | `#F2F2F2` / `#737373` + green dot |

Chip geometry: `padding: 4px 10px`, radius 9999px, font 12px weight 400, `line-height: 1.2`. Dot, where present, 6px with 5px gap.

### Astryx overrides
Astryx is tuned for full-size surfaces. Inside a 344px popover, override:

| Property | Astryx default | This app |
|---|---|---|
| Density | row 40 / text 14 | **row 32 / text 13** |
| Radius | container 16 / row 12 | **container 12 / row 8** |
| Type | Figtree everywhere | **Figtree for content · SF for system chrome** (menu bar text, native menus) |
| Elevation | `y12 blur32 / 8% alpha` | **`y8 blur24 / 32% alpha` + 1px hairline border** |
| Accent | blue carries state *and* action | **blue = action only** |
| Status axis | not in Astryx | **new: running / attention / failed** |

Hairline border: `rgba(255,255,255,0.12)` dark, `rgba(0,0,0,0.10)` light.

Accent blue `#2F6FED` is reserved for interactive elements — buttons, selected menu rows. It no longer indicates state anywhere.

### Type
- Content: **Figtree** — 13px body, 12px secondary, 11px menu bar labels.
- System chrome: **SF / `-apple-system`** — anything drawn into the menu bar or a native menu.
- Weights: 400 chips, 500 menu bar labels and body emphasis, 600 headings. Weights were deliberately dropped one step from the first pass; do not bold these back up.

## Assets
All in `assets/` in this bundle. The mark is original work for this project.

**App icon** — squircle drawn into the artwork (macOS does not mask automatically):
- `app-icon/icon-1024.png` — 1024×1024, transparent, 824px artwork + 100px margin. Dark: mark `#9EB7FF` on `#1B1B1B`.
- `app-icon/icon-1024-light.png` — same geometry. Light: mark `#171717` on `#FFFFFF` with an `#E0E0E0` hairline.
- `app-icon/agent-pulse-{dark,light}-{1024,512,256,128,64,32,16}.png` and matching `.svg`.
- The light mark is near-black, mirroring the dark icon where the mark is the lightest element on the tile. An earlier navy `#00458C` was rejected.
- Chrome extension manifest needs 128/48/16 — 48 is not yet exported.

**Menu bar template** — `app-icon/menubar-template-{dark,light}.svg`, 24×24 viewBox, stroke 2.2, round caps and joins. Ship as a template image so the system tints it; the dark/light pair is only needed for the non-template colored states.

Waveform path, for redrawing at any size in a 24×24 box:
```
M4.2 12h2.6l1.9-5.2 3.4 10.4 1.9-5.2h3
```

## Files
- `Menubar MVP - Confirmed.dc.html` — the confirmed spec. Cards C1–C7 cover logo, menu bar states, status colors, chip palette, Astryx overrides, the icon setting, and where that setting lives. Below the cards sit the 4a dropdown and 5a settings mocks.
- `Menubar MVP - Exploration Archive.dc.html` — Turns 6–15: rejected logo directions, container treatments, wallpaper contrast tests, outlined-badge study. Useful for *why* a decision went the way it did.
- `assets/`, `app-icon/` — SVG and PNG exports.

Open either HTML file directly in a browser.

## Open items
- 48px extension icon not exported.
- Light-mode variants of the empty state and onboarding screens (5b/5c) were descoped.
- Amber on bright, sand-toned wallpapers is the weakest contrast case in the system. It was accepted as-is because the filled capsule holds where a bare tile did not — but it is the first thing to re-check on real hardware.
